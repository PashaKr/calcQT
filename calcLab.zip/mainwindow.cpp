﻿// mainwindow.cpp
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPushButton>
#include <QMessageBox>
#include <QVector>
#include <QStack>
#include <QRegularExpression>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->leRes->setText("0");

    QList<QPushButton *> numButtons = {
        ui->pb_0, ui->pb_1, ui->pb_2, ui->pb_3, ui->pb_4,
        ui->pb_5, ui->pb_6, ui->pb_7, ui->pb_8, ui->pb_9
    };
    for (QPushButton *btn : numButtons)
        connect(btn, &QPushButton::clicked, this, &MainWindow::clicknum);

    connect(ui->pbdot, &QPushButton::clicked, this, &MainWindow::on_pbdot_clicked);

    QList<QPushButton*> opButtons = {
        ui->pbpl, ui->pbmin, ui->pbpr, ui->pbdiv
    };
    for (QPushButton *btn : opButtons)
        connect(btn, &QPushButton::clicked, this, &MainWindow::operatorClicked);

    connect(ui->pbequal, &QPushButton::clicked, [this]() {
        calc();
    });
    connect(ui->pb_C, &QPushButton::clicked, this, &MainWindow::C);
    connect(ui->pb_CE, &QPushButton::clicked, this, &MainWindow::CE);
    connect(ui->pbplmin, &QPushButton::clicked, this, &MainWindow::changer);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::clicknum()
{
    if (errorState) return;

    QString text = dynamic_cast<QPushButton*>(sender())->text();
    QString current = ui->leRes->text();

    if (wasJustEvaluated) {
        ui->leRes->setText(text);
        wasJustEvaluated = false;
        newInputAfterEval = true;
    } else if (current == "0" || current == "Ошибка вычисления") {
        ui->leRes->setText(text);
    } else {
        ui->leRes->setText(current + text);
    }
}

void MainWindow::on_pbdot_clicked()
{
    if (errorState) return;

    QString current = ui->leRes->text();
    if (wasJustEvaluated || current == "Ошибка вычисления") {
        ui->leRes->setText("0.");
        wasJustEvaluated = false;
        newInputAfterEval = true;
        return;
    }

    QStringList parts = current.split(QRegularExpression("[+\-*/]"), Qt::SkipEmptyParts);
    QString lastPart = parts.isEmpty() ? "" : parts.last();
    if (!lastPart.contains(".")) {
        ui->leRes->setText(current + ".");
    }
}

void MainWindow::operatorClicked()
{
    if (errorState) return;

    QString op = dynamic_cast<QPushButton*>(sender())->text();
    QString current = ui->leRes->text();

    if (wasJustEvaluated && !newInputAfterEval) {
        ui->lbl_history->setText(current + " " + op + " ");
        ui->leRes->clear();
        lastResult = current.toDouble();
    }
    else if (!ui->lbl_history->text().isEmpty() && !current.isEmpty()) {
        QString fullExpr = ui->lbl_history->text() + current;
        bool ok;
        double result = evaluateExpression(fullExpr, ok);

        if (!ok) {
            ui->leRes->setText("Ошибка вычисления");
            ui->leRes->setStyleSheet("background-color: rgb(255, 200, 200);");
            QMessageBox::critical(this, "Ошибка", "Невозможно вычислить выражение (возможно, деление на 0)");
            errorState = true;
            setButtonsEnabled(false);
            return;
        }

        ui->lbl_history->setText(QString::number(result) + " " + op + " ");
        ui->leRes->clear();
        lastResult = result;
    }
    else if (!current.isEmpty()) {
        ui->lbl_history->setText(current + " " + op + " ");
        ui->leRes->clear();
        lastResult = current.toDouble();
    }

    lastOperator = op;
    hasLastOperation = true;
    wasJustEvaluated = false;
    newInputAfterEval = false;
}

void MainWindow::C()
{
    ui->leRes->setText("0");
    ui->lbl_history->setText("");
    errorState = false;
    setButtonsEnabled(true);
    ui->leRes->setStyleSheet("");
    hasLastOperation = false;
    lastOperator.clear();
    lastOperand = 0;
    lastResult = 0;
    wasJustEvaluated = false;
    newInputAfterEval = false;
}

void MainWindow::CE()
{
    if (errorState) return;
    ui->leRes->setText("0");
    wasJustEvaluated = false;
    newInputAfterEval = false;
}

void MainWindow::changer()
{
    if (errorState) return;

    QString current = ui->leRes->text();
    if (!current.isEmpty()) {
        double val = current.toDouble();
        ui->leRes->setText(QString::number(-val));
    }
    wasJustEvaluated = false;
    newInputAfterEval = false;
}

bool MainWindow::calc()
{
    if (errorState) return false;

    QString history = ui->lbl_history->text();
    QString current = ui->leRes->text();

    if (!history.isEmpty() && !current.isEmpty()) {
        QString expr = history + current;
        bool ok;
        double result = evaluateExpression(expr, ok);

        if (!ok) {
            ui->leRes->setText("Ошибка вычисления");
            ui->leRes->setStyleSheet("background-color: rgb(255, 200, 200);");
            QMessageBox::critical(this, "Ошибка", "Невозможно вычислить выражение (возможно, деление на 0)");
            errorState = true;
            setButtonsEnabled(false);
            return false;
        }

        ui->leRes->setText(QString::number(result));
        ui->lbl_history->setText(expr + " =");

        lastResult = result;
        lastOperand = current.toDouble();
        hasLastOperation = true;
    }
    else if (hasLastOperation) {
        QString expr = QString::number(lastResult) + " " + lastOperator + " " + QString::number(lastOperand);
        bool ok;
        double result = evaluateExpression(expr, ok);

        if (!ok) {
            ui->leRes->setText("Ошибка вычисления");
            ui->leRes->setStyleSheet("background-color: rgb(255, 200, 200);");
            QMessageBox::critical(this, "Ошибка", "Невозможно вычислить выражение (возможно, деление на 0)");
            errorState = true;
            setButtonsEnabled(false);
            return false;
        }

        ui->leRes->setText(QString::number(result));
        ui->lbl_history->setText(expr + " =");
        lastResult = result;
    }

    wasJustEvaluated = true;
    newInputAfterEval = false;
    return true;
}
void MainWindow::setButtonsEnabled(bool enabled)
{
    QList<QPushButton*> buttons = {
        ui->pb_0, ui->pb_1, ui->pb_2, ui->pb_3, ui->pb_4,
        ui->pb_5, ui->pb_6, ui->pb_7, ui->pb_8, ui->pb_9,
        ui->pb_MC, ui->pb_MR, ui->pb_MS, ui->pb_Mpl, ui->pb_Mmin,
        ui->pb_CE, ui->pbplmin, ui->pbpl, ui->pbmin, ui->pbpr, ui->pbdiv,
        ui->pbdot, ui->pbequal
    };

    for (QPushButton* button : buttons) {
        button->setEnabled(enabled);
    }
}

double MainWindow::evaluateExpression(const QString &exprStr, bool &ok)
{
    ok = true;
    QString expr = exprStr;
    expr.remove(' ');

    auto precedence = [](QChar op) {
        if (op == '+' || op == '-') return 1;
        if (op == '*' || op == '/') return 2;
        return 0;
    };

    QVector<QString> output;
    QStack<QChar> ops;
    QString num;

    for (int i = 0; i < expr.length(); ++i) {
        QChar c = expr[i];

        if (c == '-' && (i == 0 || (!expr[i - 1].isDigit() && expr[i - 1] != ')'))) {
            num += c;
            continue;
        }

        if (c.isDigit() || c == '.') {
            num += c;
        } else {
            if (!num.isEmpty()) {
                output.append(num);
                num.clear();
            }

            while (!ops.isEmpty() && precedence(ops.top()) >= precedence(c)) {
                output.append(QString(ops.pop()));
            }
            ops.push(c);
        }
    }

    if (!num.isEmpty()) output.append(num);
    while (!ops.isEmpty()) output.append(QString(ops.pop()));

    QStack<double> stack;
    for (const QString &token : output) {
        if (token == "+" || token == "-" || token == "*" || token == "/") {
            if (stack.size() < 2) {
                ok = false;
                return 0;
            }
            double b = stack.pop();
            double a = stack.pop();

            if (token == "/" && b == 0) {
                ok = false;
                return 0;
            }

            if (token == "+") stack.push(a + b);
            else if (token == "-") stack.push(a - b);
            else if (token == "*") stack.push(a * b);
            else if (token == "/") stack.push(a / b);
        } else {
            bool convOk;
            double value = token.toDouble(&convOk);
            if (!convOk) {
                ok = false;
                return 0;
            }
            stack.push(value);
        }
    }

    if (stack.size() != 1) {
        ok = false;
        return 0;
    }

    return stack.top();
}

